myval = "Hello"
print(myval)
print(type(myval))
print(myval + " is of datatype " + str(type(myval)))

fstr = "water"
sstr = "fall"
tstr = fstr + sstr
print(tstr)

name = input("Enter your name: ")
print(name)
animal = input("What is your favorite animal? ")
color = input("What is your favorite color? ")
print("{}, you like {} {}!".format(name, color, animal))

