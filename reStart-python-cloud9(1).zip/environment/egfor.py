"""
for loop
"""

print("counting to 10")

for i in range(0,11) :
    print(i)