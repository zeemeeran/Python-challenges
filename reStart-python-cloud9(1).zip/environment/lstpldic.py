"""
Lists Tupple Dictionary
"""

myfr = ["apple", "banana", "cherry"]
print(myfr)
print(type(myfr))
print(myfr[0])
print(myfr[1])
print(myfr[2])

myfr[2] = "mango"

print(myfr)

myfrtpl = ("apples", "oranges", "pears")
print(myfrtpl)
print(type(myfrtpl))

print(myfrtpl[0])
print(myfrtpl[1])
print(myfrtpl[2])

myfavfrdic = { "Akua" : "Apple", "Saahvi" : "Banana", "Ram" : "Mango" }
print(myfavfrdic)
print(type(myfavfrdic))

print(myfavfrdic["Akua"])
print(myfavfrdic["Saahvi"])
print(myfavfrdic["Ram"])




